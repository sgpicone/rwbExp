const port = process.env.PORT || 8000;
process.env.DB_HOST = '165.227.177.157'
process.env.DB_PORT = '32947'
process.env.DB_USER = 'special_turd'
process.env.DB_PASS = 'IAmATurdLOLUMAD'

const app = require('./src/server.js');

console.log(process.env.DB_HOST);
// Server
app.listen(port, () => {
   console.log(`Listening on: http://localhost:${port}`);
});