const express = require('express');
const app = express();
const mysql = require('mysql');
const dbFactory = require('./dbFactory');

const port = process.env.PORT || 8000;
const baseUrl = `http://localhost:${port}`;

// var beerQueries = require('./beerQueries');
var kegQueries = require('./queries/kegQueries');
console.error(process.env.DB_HOST);
var connection = dbFactory.makeDb({
    host     : process.env.DB_HOST,
    port     : process.env.DB_PORT,
    user     : process.env.DB_USER,
    password : process.env.DB_PASS
});

// connection.connect();


app.get('/', (req, res) => {
   res.status(200).send('hello world!');
});

app.get('/kegs', async (req, res) => {
    const resp = req.query.rwbId ? 
        await kegQueries.findKegByRwbId(connection, req.query.rwbId)
        : await kegQueries.getKegs(connection);
    res.status(200).send(resp);
});

app.get('/kegs/:kegId', async (req, res) => {
    const resp = await kegQueries.getKegById(connection, req.params.kegId);
    res.status(200).send(resp);
});

// Server
module.exports = app;