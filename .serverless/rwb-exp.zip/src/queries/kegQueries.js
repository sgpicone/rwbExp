
const KEG_DETAIL_SELECT = `SELECT 
k.*, 
concat('[', group_concat('{ "date": "', kwh.WashDate, '", "chemical": "', wc.Name, '" }'), ']') as washHistory,
concat('[', group_concat('{ "date": "', ksh.SaniDate, '", "chemical": "', sc.Name, '" }'), ']') as saniHistory,
concat('[', group_concat('{ "date": "', ksale.SaleDate, '", "chemical": "', ksale.FK_CustomerId, '" }'), ']') as saleHistory
from rwbbc_data.keg_info k
left join rwbbc_data.keg_wash_history kwh on k.RWBId = kwh.FK_RWBId
left join rwbbc_data.Chemicals wc on kwh.FK_WashChemicalId = wc.Id
left join rwbbc_data.keg_sani_history ksh on k.RWBId = ksh.FK_RWBId
left join rwbbc_data.Chemicals sc on ksh.FK_WashChemicalId = sc.Id
left join rwbbc_data.keg_sale_history ksale on k.RWBId = ksale.FK_RWBId`;

const getKegs = async (connection) => {
    const rows = await connection.query(`SELECT k.*, kwh.LastWashDate, ksh.LastSaniDate, ksales.LastSaleDate, kt.Type
    FROM rwbbc_data.keg_info k
    JOIN rwbbc_data.keg_types kt ON k.KegTypeId = kt.Id
    LEFT JOIN (
        SELECT FK_RWBId, max(WashDate) AS LastWashDate
        FROM rwbbc_data.keg_wash_history
        GROUP BY FK_RWBId 
    ) kwh on k.RWBId = kwh.FK_RWBId 
    LEFT JOIN (
        SELECT FK_RWBId, max(SaniDate) AS LastSaniDate
        FROM rwbbc_data.keg_sani_history
        GROUP BY FK_RWBId 
    ) ksh on k.RWBId = ksh.FK_RWBId 
    LEFT JOIN (
        SELECT FK_RWBId, max(SaleDate) AS LastSaleDate
        FROM rwbbc_data.keg_sale_history
        GROUP BY FK_RWBId 
    ) ksales on k.RWBId = ksales.FK_RWBId`);
    console.log(rows);
    return rows;
}

const getKegDetailsById = async (connection, id) => {
    return await connection.query(
    `${KEG_DETAIL_SELECT}
    WHERE k.Id = ${id}
    group by k.RWBId;`);
}

const findKegByRwbId = async (connection, rwbId) => {
    return await connection.query(
    `${KEG_DETAIL_SELECT}
    WHERE k.RWBId = '${rwbId}'
    group by k.RWBId;`);
}

module.exports = {
    getKegs: getKegs,
    getKegById: getKegDetailsById,
    findKegByRwbId: findKegByRwbId
}